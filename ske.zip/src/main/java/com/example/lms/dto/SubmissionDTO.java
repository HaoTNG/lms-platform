package com.example.lms.dto;

public class SubmissionDTO {
    private Long id;
    private Long exerciseId;
    private Long menteeId;
}