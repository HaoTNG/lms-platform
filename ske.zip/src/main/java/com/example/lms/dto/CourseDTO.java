package com.example.lms.dto;

public class CourseDTO {
    private Long id;
    private String title;
}