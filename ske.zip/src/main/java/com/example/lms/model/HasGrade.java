package com.example.lms.model;

import jakarta.persistence.*;

/**
 * Placeholder entity: HasGrade
 * Fields and relations to be implemented by the team.
 */
@Entity
public class HasGrade {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
}
