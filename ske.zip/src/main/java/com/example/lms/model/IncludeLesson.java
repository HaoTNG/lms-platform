package com.example.lms.model;

import jakarta.persistence.*;

/**
 * Placeholder entity: IncludeLesson
 * Fields and relations to be implemented by the team.
 */
@Entity
public class IncludeLesson {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
}
