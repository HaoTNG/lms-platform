package com.example.lms.service;

import com.example.lms.dto.SubmissionDTO;
import java.util.List;

public interface SubmissionService {
    SubmissionDTO submitExercise(SubmissionDTO dto);
    SubmissionDTO getSubmission(Long id);
    List<SubmissionDTO> getSubmissionsByMentee(Long menteeId);
    List<SubmissionDTO> getSubmissionsByExercise(Long exerciseId);
}
