package com.example.lms.repository;

import com.example.lms.model.ReportTicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportTicketRepository extends JpaRepository<ReportTicket, Long> {}
